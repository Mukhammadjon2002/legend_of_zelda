#ifndef ENTERPORTALSUBTASK_H
#define ENTERPORTALSUBTASK_H

#include "global.h"

typedef struct {
    u8 paletteGroup;
    u8 gfxGroup;
} PACKED struct_080D4138;

#endif // ENTERPORTALSUBTASK_H
