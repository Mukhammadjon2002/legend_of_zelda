#ifndef INTERRUPTS_H
#define INTERRUPTS_H

extern void WaitForNextFrame(void);

#endif // INTERRUPTS_H
