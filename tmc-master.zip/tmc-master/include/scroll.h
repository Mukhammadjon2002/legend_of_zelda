#ifndef SCROLL_H
#define SCROLL_H

#include "global.h"

void UpdateIsDiggingCave(void);
void sub_08080930(u32);

#endif // SCROLL_H
