#ifndef SUBTASK2_H
#define SUBTASK2_H

void PauseMenu_Screen_4(void);
void PauseMenu_Screen_5(void);
void PauseMenu_Screen_6(void);
void PauseMenu_Screen_7(void);
void PauseMenu_Screen_8(void);
void PauseMenu_Screen_9(void);
void PauseMenu_Screen_10(void);

#endif // SUBTASK2_H
