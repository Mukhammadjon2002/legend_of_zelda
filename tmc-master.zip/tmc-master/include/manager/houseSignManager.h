#ifndef HOUSESIGNMANAGER_H
#define HOUSESIGNMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
    u32 bitfield;
} HouseSignManager;

#endif // HOUSESIGNMANAGER_H
