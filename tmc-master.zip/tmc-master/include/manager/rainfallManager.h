#ifndef RAINFALLMANAGER_H
#define RAINFALLMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} RainfallManager;

#endif // RAINFALLMANAGER_H
