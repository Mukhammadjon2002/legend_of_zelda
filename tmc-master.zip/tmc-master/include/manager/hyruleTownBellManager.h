#ifndef HYRULETOWNBELLMANAGER_H
#define HYRULETOWNBELLMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} HyruleTownBellManager;

#endif // HYRULETOWNBELLMANAGER_H
