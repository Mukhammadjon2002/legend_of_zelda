#ifndef FLOATINGPLATFORMMANAGER_H
#define FLOATINGPLATFORMMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} FloatingPlatformManager;

#endif // FLOATINGPLATFORMMANAGER_H
