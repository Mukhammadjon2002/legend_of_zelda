#ifndef POWBACKGROUNDMANAGER_H
#define POWBACKGROUNDMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} PowBackgroundManager;

#endif // POWBACKGROUNDMANAGER_H
