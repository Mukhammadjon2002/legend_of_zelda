#ifndef REPEATEDSOUNDMANAGER_H
#define REPEATEDSOUNDMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} RepeatedSoundManager;

#endif // REPEATEDSOUNDMANAGER_H
