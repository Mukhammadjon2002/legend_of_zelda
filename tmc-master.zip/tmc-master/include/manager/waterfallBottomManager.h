#ifndef WATERFALLBOTTOMMANAGER_H
#define WATERFALLBOTTOMMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} WaterfallBottomManager;

#endif // WATERFALLBOTTOMMANAGER_H
