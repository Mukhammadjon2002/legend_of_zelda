#ifndef VAATI3STARTMANAGER_H
#define VAATI3STARTMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} Vaati3StartManager;

#endif // VAATI3STARTMANAGER_H
