#ifndef CLOUDOVERLAYMANAGER_H
#define CLOUDOVERLAYMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
    u16 field_0x20;
} CloudOverlayManager;

#endif // CLOUDOVERLAYMANAGER_H
