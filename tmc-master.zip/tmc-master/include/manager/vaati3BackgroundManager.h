#ifndef VAATI3BACKGROUNDMANAGER_H
#define VAATI3BACKGROUNDMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} Vaati3BackgroundManager;

#endif // VAATI3BACKGROUNDMANAGER_H
