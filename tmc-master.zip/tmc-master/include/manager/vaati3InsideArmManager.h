#ifndef VAATI3INSIDEARMMANAGER_H
#define VAATI3INSIDEARMMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
    u16 field_0x20;
} Vaati3InsideArmManager;

#endif // VAATI3INSIDEARMMANAGER_H
