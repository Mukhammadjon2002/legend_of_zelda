#ifndef MINISHSIZEDENTRANCEMANAGER_H
#define MINISHSIZEDENTRANCEMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
    u32 field_0x20;
} MinishSizedEntranceManager;

#endif // MINISHSIZEDENTRANCEMANAGER_H
