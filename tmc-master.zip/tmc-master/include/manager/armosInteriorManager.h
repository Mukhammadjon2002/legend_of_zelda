#ifndef ARMOSINTERIORMANAGER_H
#define ARMOSINTERIORMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
} ArmosInteriorManager;

#endif // ARMOSINTERIORMANAGER_H
