#ifndef LIGHTMANAGER_H
#define LIGHTMANAGER_H

#include "manager.h"

typedef struct {
    Manager base;
    s32 unk20;
} LightManager;

#endif // LIGHTMANAGER_H
