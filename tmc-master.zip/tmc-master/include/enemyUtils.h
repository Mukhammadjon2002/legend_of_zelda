#ifndef ENEMYUTILS_H
#define ENEMYUTILS_H

#include "global.h"

typedef struct {
    u8 unk_0;
    u8 unk_1;
} PACKED struct_080D3D94;

#endif // ENEMYUTILS_H
